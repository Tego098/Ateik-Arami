# Ateik Arami — CV Website

This repository contains a single-page HTML/CSS CV website for Ateik Arami.

## Files included
- index.html
- style.css
- script.js
- assets/photo.jpg
- Ateik_Arami_CV.pdf
- Ateik_Arami_CV.docx

## Deployment (GitHub Pages via web UI)
1. Create a new GitHub repo (e.g., 'ateik-cv').
2. Upload the files above to the repository root.
3. Settings → Pages → Source: choose 'main' branch and '/' folder.
4. Save and wait — site will be: https://<username>.github.io/<repo>/

## Deployment (Git CLI)
```bash
git init
git add .
git commit -m "Initial commit: CV website"
git branch -M main
git remote add origin https://github.com/<USERNAME>/<REPO>.git
git push -u origin main
```

Contact: ateikarami@gmail.com
