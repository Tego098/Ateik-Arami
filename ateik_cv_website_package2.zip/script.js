// script.js
console.log('CV site loaded');
