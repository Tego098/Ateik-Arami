# Ateik Arami - Professional CV Website

A modern, responsive CV website showcasing logistics, supply chain, and project management expertise.

## Features

- **Responsive Design**: Mobile-first approach with seamless adaptation across all devices
- **Modern UI**: Clean, professional aesthetics with smooth animations and transitions
- **Interactive Navigation**: Smooth scrolling between sections with mobile menu support
- **SEO Optimized**: Meta tags and semantic HTML for better search engine visibility
- **Professional Sections**:
  - Hero section with profile photo
  - Professional summary
  - Key achievements with quantifiable metrics
  - Detailed work experience (expandable)
  - Education history
  - Skills categorization
  - Certifications
  - Languages and interests
  - Contact information

## Technology Stack

- **React 18** with TypeScript
- **Vite** for fast development and optimized builds
- **Tailwind CSS** for styling
- **Lucide React** for professional icons
- **Responsive Design** with mobile-first approach

## Getting Started

### Prerequisites

- Node.js 18+ installed
- npm or yarn package manager

### Installation

1. Clone or download the project
2. Install dependencies:

```bash
npm install
```

### Development

Run the development server:

```bash
npm run dev
```

The site will be available at `http://localhost:5173`

### Build for Production

```bash
npm run build
```

The optimized production files will be in the `dist` folder.

### Preview Production Build

```bash
npm run preview
```

## Updating the Professional Photo

The professional photo is referenced in `/src/components/Hero.tsx`. Currently, it points to `/Photo 2.pdf`.

To update the photo:

1. Convert the PDF to an image format (JPG or PNG recommended)
2. Place the image in the `/public` folder (e.g., `/public/profile-photo.jpg`)
3. Update the image source in `src/components/Hero.tsx`:

```tsx
<img
  src="/profile-photo.jpg"
  alt="Ateik Arami"
  className="w-full h-full object-cover"
/>
```

### Converting PDF to Image

You can use online tools or command-line tools:

**Using ImageMagick (command line):**
```bash
convert -density 300 "Photo 2.pdf" -quality 90 profile-photo.jpg
```

**Using online tools:**
- https://www.pdf2jpg.net/
- https://cloudconvert.com/pdf-to-jpg

## Customization

### Colors

The site uses a professional color scheme with blues and slate grays. To customize:

- Primary color: `blue-600` (used for buttons, links, accents)
- Dark backgrounds: `slate-900`, `slate-800`
- Text colors: `slate-900`, `slate-700`, `slate-600`

Update these in the component files or extend the Tailwind config.

### Content

All content is maintained in the component files under `/src/components/`:

- `Hero.tsx` - Header section with name and title
- `ProfessionalSummary.tsx` - About/summary section
- `KeyAchievements.tsx` - Achievements with metrics
- `Experience.tsx` - Work history
- `Education.tsx` - Academic qualifications
- `Skills.tsx` - Skills and expertise
- `Certifications.tsx` - Professional credentials
- `Languages.tsx` - Languages and interests

### Contact Information

Update contact details in:
- `src/components/Hero.tsx` (hero section links)
- `src/App.tsx` (footer contact section)

## Deployment

### Deploy to Netlify

1. Build the project: `npm run build`
2. Deploy the `dist` folder to Netlify
3. Or connect your GitHub repository to Netlify for automatic deployments

### Deploy to Vercel

1. Install Vercel CLI: `npm i -g vercel`
2. Run: `vercel`
3. Follow the prompts

### Deploy to GitHub Pages

1. Install gh-pages: `npm install --save-dev gh-pages`
2. Add to package.json scripts:
```json
"predeploy": "npm run build",
"deploy": "gh-pages -d dist"
```
3. Run: `npm run deploy`

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance

- Optimized images and assets
- Code splitting with Vite
- Lazy loading where appropriate
- Minimal bundle size

## License

All rights reserved. © 2025 Ateik Arami

## Contact

For updates or questions about this website:
- Email: ateikarami@gmail.com
- LinkedIn: [linkedin.com/in/ateik-arami-2739661b2](https://linkedin.com/in/ateik-arami-2739661b2)
