import { Mail, Phone, Linkedin, MapPin, Download, Menu, X, ExternalLink } from 'lucide-react';
import { useState } from 'react';
import Hero from './components/Hero';
import ProfessionalSummary from './components/ProfessionalSummary';
import KeyAchievements from './components/KeyAchievements';
import Experience from './components/Experience';
import Education from './components/Education';
import Skills from './components/Skills';
import Certifications from './components/Certifications';
import Languages from './components/Languages';

function App() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setMobileMenuOpen(false);
    }
  };

  const navItems = [
    { id: 'about', label: 'About' },
    { id: 'achievements', label: 'Achievements' },
    { id: 'experience', label: 'Experience' },
    { id: 'education', label: 'Education' },
    { id: 'skills', label: 'Skills' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-blue-50">
      <nav className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <h1 className="text-xl font-bold text-slate-800">Ateik Arami</h1>
            </div>

            <div className="hidden md:flex space-x-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="text-slate-600 hover:text-blue-600 transition-colors duration-200 font-medium"
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="hidden md:flex items-center space-x-4">
              <a
                href="mailto:ateikarami@gmail.com"
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-200 shadow-md hover:shadow-lg"
              >
                <Mail className="w-4 h-4 mr-2" />
                Contact
              </a>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-slate-100 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden border-t border-slate-200 bg-white">
            <div className="px-4 py-4 space-y-3">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="block w-full text-left px-4 py-2 text-slate-600 hover:bg-slate-50 rounded-lg transition-colors"
                >
                  {item.label}
                </button>
              ))}
              <a
                href="mailto:ateikarami@gmail.com"
                className="flex items-center justify-center w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Mail className="w-4 h-4 mr-2" />
                Contact
              </a>
            </div>
          </div>
        )}
      </nav>

      <div className="pt-16">
        <Hero />
        <ProfessionalSummary />
        <KeyAchievements />
        <Experience />
        <Education />
        <Skills />
        <Certifications />
        <Languages />

        <section id="contact" className="py-20 bg-slate-900 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
              <p className="text-slate-300 text-lg">Open to relocation & international deployment</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <a
                href="mailto:ateikarami@gmail.com"
                className="flex items-center justify-center p-6 bg-slate-800 rounded-lg hover:bg-slate-700 transition-all duration-200 hover:scale-105"
              >
                <Mail className="w-5 h-5 mr-3 text-blue-400" />
                <span className="text-sm">ateikarami@gmail.com</span>
              </a>

              <a
                href="tel:+967737820677"
                className="flex items-center justify-center p-6 bg-slate-800 rounded-lg hover:bg-slate-700 transition-all duration-200 hover:scale-105"
              >
                <Phone className="w-5 h-5 mr-3 text-blue-400" />
                <span className="text-sm">+967 737 820 677</span>
              </a>

              <a
                href="https://wa.me/447752460524"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center p-6 bg-slate-800 rounded-lg hover:bg-slate-700 transition-all duration-200 hover:scale-105"
              >
                <Phone className="w-5 h-5 mr-3 text-green-400" />
                <span className="text-sm">WhatsApp</span>
              </a>

              <a
                href="https://linkedin.com/in/ateik-arami-2739661b2"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center p-6 bg-slate-800 rounded-lg hover:bg-slate-700 transition-all duration-200 hover:scale-105"
              >
                <Linkedin className="w-5 h-5 mr-3 text-blue-400" />
                <span className="text-sm">LinkedIn</span>
              </a>
            </div>

            <div className="text-center text-slate-400 text-sm">
              <p>&copy; 2025 Ateik Arami. All rights reserved.</p>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

export default App;
