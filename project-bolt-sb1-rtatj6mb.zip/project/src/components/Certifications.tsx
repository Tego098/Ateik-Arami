import { Award, CheckCircle } from 'lucide-react';

export default function Certifications() {
  const certifications = [
    'PRINCE2 Preparation',
    'SAP ERP Logistics',
    'SAP MM & Logistics',
    'Humanitarian Grants & Donor Compliance',
    'Data Analysis & Reporting',
    'AI Community Certification',
    'Fleet & Asset Management (Humanitarian)',
  ];

  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-4">
            <Award className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Certifications
          </h2>
          <p className="text-slate-600 text-lg">
            Professional credentials and specialized training
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl shadow-md border border-slate-200 p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {certifications.map((cert, index) => (
                <div
                  key={index}
                  className="flex items-start group hover:bg-slate-50 p-4 rounded-lg transition-colors"
                >
                  <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                  <span className="text-slate-700 font-medium group-hover:text-slate-900">
                    {cert}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
