import { TrendingUp, Truck, Zap, Wrench, FileText, Bot } from 'lucide-react';

export default function KeyAchievements() {
  const achievements = [
    {
      icon: TrendingUp,
      percentage: '30%',
      title: 'Procurement Efficiency',
      description: 'Increased efficiency through streamlined sourcing and documentation systems',
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      icon: Truck,
      percentage: '15%',
      title: 'Cost Reduction',
      description: 'Reduced fleet management costs using preventive maintenance and vendor optimization',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      icon: Zap,
      percentage: '40 MW',
      title: 'Infrastructure Project',
      description: 'Contributed to successful delivery of national energy project with zero safety incidents',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
    },
    {
      icon: Wrench,
      percentage: '20%',
      title: 'Vehicle Uptime',
      description: 'Improved uptime through structured maintenance planning',
      color: 'text-teal-600',
      bgColor: 'bg-teal-50',
    },
    {
      icon: FileText,
      percentage: 'SOPs',
      title: 'Process Documentation',
      description: 'Created dashboards and monitoring systems for academic and private institutions',
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
    },
    {
      icon: Bot,
      percentage: 'AI',
      title: 'AramiAI Development',
      description: 'Developed AI-assisted tools strengthening forecasting, compliance, and reporting',
      color: 'text-rose-600',
      bgColor: 'bg-rose-50',
    },
  ];

  return (
    <section id="achievements" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Key Achievements
          </h2>
          <p className="text-slate-600 text-lg">
            Quantifiable results from complex operational environments
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {achievements.map((achievement, index) => {
            const Icon = achievement.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-slate-100"
              >
                <div className={`w-16 h-16 ${achievement.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                  <Icon className={`w-8 h-8 ${achievement.color}`} />
                </div>

                <div className={`text-3xl font-bold ${achievement.color} mb-2`}>
                  {achievement.percentage}
                </div>

                <h3 className="text-xl font-semibold text-slate-900 mb-2">
                  {achievement.title}
                </h3>

                <p className="text-slate-600 leading-relaxed">
                  {achievement.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
