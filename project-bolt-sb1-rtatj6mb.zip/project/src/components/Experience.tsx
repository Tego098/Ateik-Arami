import { Briefcase, MapPin, Calendar, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

interface ExperienceItem {
  title: string;
  company: string;
  location: string;
  period: string;
  description: string[];
}

export default function Experience() {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(0);

  const experiences: ExperienceItem[] = [
    {
      title: 'Supply Chain & Project Coordinator',
      company: '40 MW National Infrastructure Project',
      location: 'Mocha, Yemen',
      period: 'Oct 2024 – Sep 2025',
      description: [
        'Coordinated logistics, procurement cycles, inventory control, and vendor relations for energy infrastructure',
        'Managed transport operations, material handling, container tracking, and delivery verification',
        'Maintained compliance documentation, manifests, delivery notes, and asset registers',
        'Implemented digital documentation systems ensuring audit readiness and transparency',
        'Collaborated with engineering teams, contractors, and local authorities for smooth project delivery',
      ],
    },
    {
      title: 'Senior Business Consultant',
      company: 'Northumbria University',
      location: 'Newcastle, UK',
      period: 'Jan 2023 – Sep 2024',
      description: [
        'Developed SOPs, workflow systems, and operational frameworks for institutional improvement',
        'Conducted data-driven analysis, risk assessments, and process optimization studies',
        'Created monitoring dashboards and reporting templates used across academic programs',
        'Researched sustainable supply chains and led policy- and data-focused projects',
        'Trained teams on documentation control, workflow automation, and operational planning',
      ],
    },
    {
      title: 'Supply Chain & Logistics Coordinator',
      company: 'Ringtons Ltd.',
      location: 'Newcastle, UK',
      period: 'May 2021 – Dec 2022',
      description: [
        'Managed import/export documentation, customs processes, and vendor communication',
        'Oversaw procurement cycles, inventory monitoring, and warehouse operations',
        'Improved reporting accuracy through digitized procurement and delivery systems',
        'Supported production and distribution planning in coordination with technical teams',
      ],
    },
    {
      title: 'Logistics & Records Management Officer',
      company: 'Humanitarian & Private Projects',
      location: 'Yemen & UK',
      period: 'Jun 2021 – Sep 2024',
      description: [
        'Managed procurement files, fleet records, warehouse documentation, and asset tracking',
        'Coordinated vendor relations, maintenance contracts, utilities, and facility administration',
        'Ensured compliance with donor regulations and organizational procurement policies',
        'Supported humanitarian operations with WHO, WFP, IOM, and UNICEF',
      ],
    },
    {
      title: 'Founder',
      company: 'AramiAI (AI for Supply Chain Automation)',
      location: 'Remote',
      period: '2024 – Present',
      description: [
        'Developing AI-powered systems for procurement automation, forecasting, and documentation control',
        'Designing tools to support SMEs, humanitarian organizations, and logistics teams',
        'Leading product mapping, testing, and integration workflows',
      ],
    },
  ];

  return (
    <section id="experience" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Professional Experience
          </h2>
          <p className="text-slate-600 text-lg">
            Multidisciplinary expertise across sectors and regions
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-6">
          {experiences.map((exp, index) => (
            <div
              key={index}
              className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-blue-300 transition-all duration-300 shadow-sm hover:shadow-md"
            >
              <button
                onClick={() => setExpandedIndex(expandedIndex === index ? null : index)}
                className="w-full p-6 text-left"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Briefcase className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-slate-900">{exp.title}</h3>
                        <p className="text-blue-600 font-semibold">{exp.company}</p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-4 mt-3 ml-15">
                      <div className="flex items-center text-slate-600 text-sm">
                        <MapPin className="w-4 h-4 mr-2" />
                        {exp.location}
                      </div>
                      <div className="flex items-center text-slate-600 text-sm">
                        <Calendar className="w-4 h-4 mr-2" />
                        {exp.period}
                      </div>
                    </div>
                  </div>

                  <div className="ml-4">
                    {expandedIndex === index ? (
                      <ChevronUp className="w-6 h-6 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                </div>
              </button>

              {expandedIndex === index && (
                <div className="px-6 pb-6 ml-15">
                  <ul className="space-y-3">
                    {exp.description.map((item, i) => (
                      <li key={i} className="flex items-start">
                        <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                        <span className="text-slate-700">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
