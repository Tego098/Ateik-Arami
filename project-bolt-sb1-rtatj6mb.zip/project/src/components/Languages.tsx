import { Globe, Heart, Lightbulb, Truck } from 'lucide-react';

export default function Languages() {
  const languages = [
    { language: 'Arabic', level: 'Native', percentage: 100 },
    { language: 'English', level: 'Fluent', percentage: 100 },
  ];

  const interests = [
    { icon: Truck, title: 'Humanitarian Logistics', color: 'text-blue-600', bgColor: 'bg-blue-50' },
    { icon: Globe, title: 'Field Coordination', color: 'text-teal-600', bgColor: 'bg-teal-50' },
    { icon: Lightbulb, title: 'AI & Supply Chain Automation', color: 'text-orange-600', bgColor: 'bg-orange-50' },
    { icon: Heart, title: 'Sustainable Development', color: 'text-green-600', bgColor: 'bg-green-50' },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <div className="flex items-center mb-8">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                <Globe className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900">Languages</h2>
            </div>

            <div className="space-y-6">
              {languages.map((lang, index) => (
                <div key={index} className="bg-slate-50 rounded-xl p-6 border border-slate-200">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-lg font-semibold text-slate-900">{lang.language}</span>
                    <span className="text-sm font-medium text-blue-600">{lang.level}</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-blue-600 to-blue-500 h-full rounded-full transition-all duration-1000"
                      style={{ width: `${lang.percentage}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center mb-8">
              <div className="w-12 h-12 bg-teal-600 rounded-lg flex items-center justify-center mr-4">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900">Interests</h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {interests.map((interest, index) => {
                const Icon = interest.icon;
                return (
                  <div
                    key={index}
                    className="bg-white border border-slate-200 rounded-xl p-6 hover:border-blue-300 transition-all duration-300 hover:-translate-y-1 shadow-sm hover:shadow-md"
                  >
                    <div className={`w-12 h-12 ${interest.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                      <Icon className={`w-6 h-6 ${interest.color}`} />
                    </div>
                    <h3 className="text-base font-semibold text-slate-900 leading-snug">
                      {interest.title}
                    </h3>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
