export default function ProfessionalSummary() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-8 text-center">
            Professional Summary
          </h2>

          <div className="prose prose-lg max-w-none">
            <p className="text-slate-700 leading-relaxed mb-6">
              Versatile Supply Chain, Logistics, and Project Management Professional with a multidisciplinary
              background spanning humanitarian operations, private-sector logistics, academic consulting, and
              national infrastructure projects. Strong command of procurement, vendor negotiations, warehouse
              operations, inventory control, logistics coordination, and process optimization.
            </p>

            <p className="text-slate-700 leading-relaxed mb-6">
              In the humanitarian sector, supported operational logistics across Yemen in collaboration with
              <span className="font-semibold text-slate-900"> WHO, WFP, UNICEF, and IOM</span>, ensuring
              timely movement of supplies, accuracy of documentation, and compliance with donor frameworks.
              In the private sector, managed imports/exports, customs documentation, and supply planning for
              UK-based companies, improving efficiency, accuracy, and overall operational performance.
            </p>

            <p className="text-slate-700 leading-relaxed mb-6">
              As a Project Coordinator on a major <span className="font-semibold text-slate-900">40 MW energy project</span>,
              oversaw transport operations, material handling, contractor coordination, asset tracking, and critical
              compliance records. Developed SOPs and documentation systems for universities, businesses, and
              humanitarian programs, strengthening governance, audit readiness, and internal control mechanisms.
            </p>

            <p className="text-slate-700 leading-relaxed">
              Founder of <span className="font-semibold text-blue-600">AramiAI</span>, an AI initiative automating
              procurement documentation, forecasting, and compliance reporting for supply chain operations. Known
              for structured execution, strong analytical skills, critical thinking, and the ability to bring clarity,
              efficiency, and accountability to complex operational environments.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
