import { Package, Cog, Code, Users } from 'lucide-react';

export default function Skills() {
  const skillCategories = [
    {
      title: 'Supply Chain & Logistics',
      icon: Package,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      skills: [
        'Procurement',
        'Vendor Management',
        'Warehouse Operations',
        'Fleet Management',
        'Inventory Control',
        'Import/Export',
        'Transport Coordination',
        'Humanitarian Logistics',
        'Asset Management',
      ],
    },
    {
      title: 'Project & Operations',
      icon: Cog,
      color: 'text-teal-600',
      bgColor: 'bg-teal-50',
      skills: [
        'SOP Development',
        'Reporting & Compliance',
        'Monitoring & Evaluation',
        'Risk Management',
        'Process Improvement',
        'Operational Planning',
        'Documentation Systems',
      ],
    },
    {
      title: 'Technical Tools',
      icon: Code,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      skills: [
        'SAP ERP',
        'SAP MM',
        'SAP Logistics',
        'Microsoft 365',
        'Power BI',
        'Data Analysis',
        'Digital Documentation',
      ],
    },
    {
      title: 'Soft Skills',
      icon: Users,
      color: 'text-rose-600',
      bgColor: 'bg-rose-50',
      skills: [
        'Critical Thinking',
        'Coordination',
        'Communication',
        'Problem Solving',
        'Time Management',
        'Analytical Decision-Making',
        'Cross-Cultural Collaboration',
      ],
    },
  ];

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Skills & Expertise
          </h2>
          <p className="text-slate-600 text-lg">
            Comprehensive skill set across logistics, operations, and technology
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {skillCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <div
                key={index}
                className="bg-white border border-slate-200 rounded-xl p-8 hover:border-blue-300 transition-all duration-300 shadow-sm hover:shadow-md"
              >
                <div className="flex items-center mb-6">
                  <div className={`w-12 h-12 ${category.bgColor} rounded-lg flex items-center justify-center mr-4`}>
                    <Icon className={`w-6 h-6 ${category.color}`} />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900">
                    {category.title}
                  </h3>
                </div>

                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, skillIndex) => (
                    <span
                      key={skillIndex}
                      className="px-4 py-2 bg-slate-50 text-slate-700 rounded-lg text-sm font-medium hover:bg-slate-100 transition-colors"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 bg-gradient-to-r from-blue-50 to-teal-50 rounded-xl p-8 border border-blue-100">
          <h3 className="text-xl font-bold text-slate-900 mb-4">
            Core Strengths
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[
              'Critical Thinking',
              'Procurement Expertise',
              'Reporting & Compliance',
              'Problem Solving',
              'Coordination',
              'Workflow Management',
            ].map((strength, index) => (
              <div
                key={index}
                className="bg-white rounded-lg p-4 text-center shadow-sm hover:shadow-md transition-shadow"
              >
                <p className="text-sm font-semibold text-slate-700">{strength}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
