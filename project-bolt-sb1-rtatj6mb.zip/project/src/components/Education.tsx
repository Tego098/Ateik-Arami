import { GraduationCap, BookOpen } from 'lucide-react';

export default function Education() {
  const education = [
    {
      degree: 'MSc in Project Management',
      institution: 'Northumbria University, UK',
      period: '2023 – 2024',
      focus: 'Operations, Leadership, Change Management, Budgeting, Analytics, Performance Monitoring',
      color: 'bg-blue-600',
    },
    {
      degree: 'BA in Logistics & Supply Chain Management',
      institution: 'Northumbria University, UK',
      period: '2020 – 2023',
      focus: 'Global Logistics, Procurement, Sustainable SCM, Inventory Management, Risk & Operations',
      color: 'bg-teal-600',
    },
    {
      degree: 'Diploma in Academic Communication',
      institution: 'Northumbria University, UK',
      period: '2019 – 2020',
      focus: 'Professional Communication, Research Methods, Academic Writing',
      color: 'bg-slate-600',
    },
  ];

  return (
    <section id="education" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Education
          </h2>
          <p className="text-slate-600 text-lg">
            Strong academic foundation in logistics and project management
          </p>
        </div>

        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {education.map((edu, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border border-slate-100"
            >
              <div className={`w-14 h-14 ${edu.color} rounded-lg flex items-center justify-center mb-4`}>
                <GraduationCap className="w-7 h-7 text-white" />
              </div>

              <h3 className="text-xl font-bold text-slate-900 mb-2">
                {edu.degree}
              </h3>

              <p className="text-blue-600 font-semibold mb-2">
                {edu.institution}
              </p>

              <p className="text-slate-500 text-sm mb-4">
                {edu.period}
              </p>

              <div className="flex items-start pt-4 border-t border-slate-100">
                <BookOpen className="w-4 h-4 text-slate-400 mr-2 mt-1 flex-shrink-0" />
                <p className="text-sm text-slate-600 leading-relaxed">
                  {edu.focus}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
